## Website

http://www.eg.bucknell.edu/~cs475/F2000-S2001/hyde/JUnit/

## Background

JUnit is a simple unit testing framework for Java. It was implemented by Kent Beck and Erich Gamma.

## Contents

All files in Bucknell directory /home/hydra/COURSES/cs475/public_html/F2000-S2001/hyde/JUnit

```
README.html           this file slightly moddified for Bucknell's local environment
    test.jar                    a jar file with the junit classes
    test                        the source code
        framework               the testing framework
        textui                  a command line interface to run tests
        ui                      a simple graphical user interface to run tests
    samples                     some example test cases and extensions to the framework
        money                   a sample illustrating testing
                                arithmetic with multiple currencies
    doc                         documentation
    javadoc                     javadoc documentation
```

## Installation

To use the test framework add test.jar to your CLASSPATH. Add to your .cshrc file the following::

```
setenv JUnitDIR /home/hydra/COURSES/cs475/public_html/F2000-S2001/hyde/JUnit
### CLASSPATH - environment variable for JAVA
setenv CLASSPATH .:path1:path2:$JUnitDIR/test.jar
where "path1" and "path2" are where you keep your Java class files.
```